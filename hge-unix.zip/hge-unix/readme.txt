
This is a Mac and Unix port of HGE. Ryan C. Gordon did the initial porting
work for Red Marble Games, and it is shipping in the Mac versions of several
of their games.

Questions about this library on Mac and Linux can be sent to Ryan:

    icculus@icculus.org

I don't know anything about the Windows version of HGE.

The original HGE readme is below.

--ryan.



Haaf's Game Engine 1.81
Copyright (C) 2003-2008, Relish Games
http://hge.relishgames.com

HGE is an easy to use yet powerful hardware accelerated 2D game engine.
It is a full featured middleware for all who want to develop commercial
quality 2D games rapidly and easily. It covers all imaginable 2D game
genres: you could create everything from a simple puzzle to advanced
multilayered platformer or strategy without even thinking of any non
game logic code! And you don't have to know anything about "window
messages", DirectX programming and all that stuff. Instead you can
start developing your own game within 15 minutes! 

HGE runs on Microsoft Windows 98, 2000, NT, ME, XP and requires
DirectX 8.0. It will run even on low-end video cards, including
built in video cards such as Intel Solano (i815 chipset). HGE can
be used with virtually any C++ compiler including Visual C++,
Borland C++, MinGW and Metrowerks Codewarrior. 

See documentation for details.
See license.txt for licensing information.
Send any questions, suggestions and bug reports to hge@relishgames.com.


Cheers! :)
